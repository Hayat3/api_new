from flask import Flask, request, jsonify
from flask_restful import Resource, Api
from flaskext.mysql import MySQL
import sys
from flask_cors import CORS

mysql = MySQL()
app = Flask(__name__)
CORS(app)
#db and customized port details
port = 4003
env = "assessmenttest"
if __name__ == "__main__":
    if len(sys.argv) > 1:
        env = sys.argv[1]
        print("env=" + env)
    if len(sys.argv) > 2:
        port = sys.argv[2]
        print("port=" + port)

# MySQL configurations
app.config['MYSQL_DATABASE_USER'] = 'root'
app.config['MYSQL_DATABASE_PASSWORD'] = 'Hayath#22'
app.config['MYSQL_DATABASE_DB'] = env
app.config['MYSQL_DATABASE_HOST'] = 'localhost'

mysql.init_app(app)

api = Api(app)

#class with method post to insert customer name
class CustomerInsert(Resource):
    def post(self):
        data = request.get_json()
        conn = mysql.connect()
        cursor = conn.cursor()
        insert_query = "insert into customer (firstname, lastname,email,pass) values ( '" + data['firstname'] + "', '" + data['lastname'] + "','" + data['email'] + "','" + data['password'] + "')"
        cursor.execute(insert_query)
        conn.commit()
        conn.close()
        customer = {'inserted':'success'}
        return customer, 201

api.add_resource(CustomerInsert, '/customerinsert/')


app.run(port=port)
