import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl,Validators} from '@angular/forms';
import {HttpClient} from '@angular/common/http';
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  public reactiveForm;
  Firstname:string;
  lastname:string;
  pass:string;
  mail:string;
  image:string;

  constructor(private http:HttpClient) { }

  ngOnInit(): void {
    this.reactiveForm=new FormGroup({
      name:new FormControl('',Validators.required),
      email:new FormControl('',[Validators.required,Validators.email]),
      LastName:new FormControl('',Validators.required),
      password:new FormControl('',[Validators.required,Validators.maxLength(6)]),
      filecheck:new FormControl('',Validators.required)
    })

  }
  onSubmit() {
    if(this.reactiveForm.valid==true)
    {
      let url="http://127.0.0.1:4003/customerinsert/";
      this.http.post(url,{firstname:this.Firstname,lastname:this.lastname,email:this.mail,password:this.pass,image:this.image}).subscribe((data:any)=>{console.log(data);
      })
    }
  }

}
